import './About.scss';
import Carousel from './Component/Carousel';
import Header from './Component/Header';
import Main from './Component/Main';
import Nav from './Component/Nav';
import Navbar from './Component/Navbar';


function App() {
  return (
    <div>
      <Header/>
      <Nav/>
      <Navbar/>
      <Main/>
      <Carousel/>
    </div>
  );
}

export default App;
